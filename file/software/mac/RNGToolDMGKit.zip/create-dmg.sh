#!/usr/bin/env bash

#if [[ -e ../../create-dmg ]]; then
  # We're running from the repo
  #CREATE_DMG=../../create-dmg
#else
  # We're running from an installation under a prefix
  #CREATE_DMG=../../../../bin/create-dmg
#fi

# Since create-dmg does not clobber, be sure to delete previous DMG
[[ -f RNGTool-Swift-Installer.dmg ]] && rm RNGTool-Swift-Installer.dmg

# Create the DMG
create-dmg \
  --volname "RNGTool Installer" \
  --volicon "RNGToolDMG.icns" \
  --background "background.png" \
  --window-pos 200 120 \
  --window-size 500 370 \
  --icon-size 80 \
  --icon "RNGTool.app" 125 160 \
  --hide-extension "RNGTool.app" \
  --app-drop-link 375 160 \
  "RNGTool-Installer.dmg" \
  "source_folder/"